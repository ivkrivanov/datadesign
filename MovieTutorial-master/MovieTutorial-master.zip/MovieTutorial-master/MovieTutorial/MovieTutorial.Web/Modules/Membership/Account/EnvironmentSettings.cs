﻿
namespace MovieTutorial
{
    using Serenity.Services;
    using System;

    public class EnvironmentSettings
    {
        public string SiteExternalUrl { get; set; }
    }
}
﻿namespace MovieTutorial.Administration {
    export interface UserRoleListRequest extends Serenity.ServiceRequest {
        UserID?: number
    }
}


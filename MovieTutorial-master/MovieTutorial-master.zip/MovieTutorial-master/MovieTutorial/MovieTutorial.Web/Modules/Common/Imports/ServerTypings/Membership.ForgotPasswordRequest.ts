﻿namespace MovieTutorial.Membership {
    export interface ForgotPasswordRequest extends Serenity.ServiceRequest {
        Email?: string
    }
}


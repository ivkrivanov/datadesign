﻿namespace MovieTutorial.Administration {
    export interface UserRoleListResponse extends Serenity.ListResponse<number> {
    }
}


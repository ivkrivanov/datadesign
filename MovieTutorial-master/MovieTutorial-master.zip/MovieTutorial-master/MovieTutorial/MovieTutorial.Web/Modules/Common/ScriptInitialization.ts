﻿namespace MovieTutorial.ScriptInitialization {
    Q.Config.responsiveDialogs = true;
    Q.Config.rootNamespaces.push('MovieTutorial');
}
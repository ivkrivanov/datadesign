﻿
namespace MovieTutorial.Administration
{
    using Serenity;
    using Serenity.Services;
    using Serenity.Web;
    using System;
    using System.Web.Mvc;

    public class UserRoleListResponse : ListResponse<Int32>
    {
    }
}
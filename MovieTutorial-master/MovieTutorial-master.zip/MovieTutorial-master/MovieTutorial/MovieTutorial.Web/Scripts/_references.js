﻿/// <reference path="jquery-ui-1.11.4.js" />
/// <autosync enabled="false" />
/// <reference path="jquery-2.2.3.js" />
/// <reference path="serenity/Serenity.CoreLib.js" />
/// <reference path="serenity/Serenity.Externals.js" />
/// <reference path="serenity/Serenity.Externals.Slick.js" />
/// <reference path="serenity/Serenity.Script.UI.js" />
/// <reference path="site/MovieTutorial.Web.js" />
